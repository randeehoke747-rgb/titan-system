# Fourmilab → Titan integration

Titan uses the Fourmilab Blockchain Tools design as a read-only blockchain safety layer.

## Integrated capabilities

1. **Address Watch** → Titan watchlist API. Bitcoin/EVM addresses can be registered and normalized.
2. **Cold Storage Monitor** → expected-vs-observed balance checks with tolerance and alerts.
3. **Confirmation Watch** → deterministic confirmation calculation for a transaction/block height.
4. **Transaction Fee Watch** → elevated-fee and maximum-fee policy checks.
5. **Wallet validation workflow** → offline-only validation remains a separate workflow; private keys are not accepted by Titan's online control-plane APIs.
6. **Multiple Key Manager concept** → custody policy is documented as an offline/manual operation. Titan does not reconstruct private keys inside the online agent mesh.
7. **Address/key generation** → kept out of the online autonomous agent path; generation belongs on an isolated machine.

## Titan endpoints

- `GET /blockchain/status`
- `GET /blockchain/watch`
- `POST /blockchain/watch`
- `POST /blockchain/cold-storage/evaluate`
- `POST /blockchain/confirmations`
- `POST /blockchain/fees/evaluate`

All mutation/evaluation endpoints require the configured operator bearer token.

## Security boundary

The Titan agents may **detect, score, quarantine, alert, and request human authorization**. They do not receive private keys from the watch/monitoring API and do not autonomously sign or broadcast a recovery transaction.
