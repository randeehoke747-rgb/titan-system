//! Titan's read-only blockchain safety layer inspired by Fourmilab Blockchain Tools.
//!
//! This module deliberately keeps signing, broadcasting, and private-key material
//! outside the control plane. It provides watchlists, cold-storage drift detection,
//! confirmation tracking, and fee telemetry that can feed the Titan security gateway.

use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct WatchedAddress {
    pub address: String,
    pub chain: String,
    pub label: Option<String>,
    pub expected_balance: Option<f64>,
    pub tolerance: f64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct BalanceObservation {
    pub address: String,
    pub chain: String,
    pub expected: f64,
    pub observed: f64,
    pub tolerance: f64,
    pub drift: f64,
    pub alert: bool,
    pub reason: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ConfirmationCheck {
    pub txid: String,
    pub block_height: u64,
    pub current_height: u64,
    pub confirmations: u64,
    pub required: u64,
    pub confirmed: bool,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FeeObservation {
    pub chain: String,
    pub observed_fee_rate: f64,
    pub recommended_fee_rate: Option<f64>,
    pub max_allowed_fee_rate: Option<f64>,
    pub elevated: bool,
    pub rejected: bool,
}

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct BlockchainSecurityState {
    pub watched: Vec<WatchedAddress>,
    pub alerts: Vec<String>,
    pub last_bitcoin_height: Option<u64>,
    pub observations: Vec<BalanceObservation>,
    pub confirmations: Vec<ConfirmationCheck>,
    pub fees: Vec<FeeObservation>,
}

#[derive(Clone, Debug, Default)]
pub struct BlockchainSecurityEngine {
    watched: HashMap<String, WatchedAddress>,
    state: BlockchainSecurityState,
}

impl BlockchainSecurityEngine {
    pub fn new() -> Self { Self::default() }

    pub fn add_watch(&mut self, mut item: WatchedAddress) -> Result<(), String> {
        item.address = item.address.trim().to_owned();
        item.chain = item.chain.trim().to_ascii_lowercase();
        if !validate_address(&item.chain, &item.address) {
            return Err(format!("unsupported or malformed {} address", item.chain));
        }
        if item.tolerance < 0.0 { return Err("tolerance cannot be negative".into()); }
        self.watched.insert(item.address.clone(), item.clone());
        self.state.watched = self.watched.values().cloned().collect();
        Ok(())
    }

    pub fn watches(&self) -> Vec<WatchedAddress> {
        self.watched.values().cloned().collect()
    }

    pub fn evaluate_balance(&mut self, observation: BalanceObservation) -> BalanceObservation {
        let alert = (observation.observed - observation.expected).abs() > observation.tolerance;
        let mut result = observation;
        result.drift = result.observed - result.expected;
        result.alert = alert;
        result.reason = if alert {
            "balance differs from expected cold-storage balance".into()
        } else {
            "balance within configured tolerance".into()
        };
        if alert {
            self.state.alerts.push(format!(
                "{} {} balance drift: expected={}, observed={}",
                result.chain, result.address, result.expected, result.observed
            ));
        }
        self.state.observations.push(result.clone());
        result
    }

    pub fn check_confirmations(&mut self, txid: String, block_height: u64, current_height: u64, required: u64) -> ConfirmationCheck {
        let confirmations = if current_height >= block_height { current_height - block_height + 1 } else { 0 };
        let check = ConfirmationCheck { txid, block_height, current_height, confirmations, required, confirmed: confirmations >= required };
        self.state.confirmations.push(check.clone());
        check
    }

    pub fn evaluate_fee(&mut self, observation: FeeObservation) -> FeeObservation {
        let elevated = observation.recommended_fee_rate.map(|r| observation.observed_fee_rate > r * 1.5).unwrap_or(false);
        let rejected = observation.max_allowed_fee_rate.map(|m| observation.observed_fee_rate > m).unwrap_or(false);
        let result = FeeObservation { elevated, rejected, ..observation };
        if rejected {
            self.state.alerts.push(format!("{} fee rate exceeded configured maximum", result.chain));
        }
        self.state.fees.push(result.clone());
        result
    }

    pub fn set_bitcoin_height(&mut self, height: u64) { self.state.last_bitcoin_height = Some(height); }
    pub fn status(&self) -> BlockchainSecurityState { self.state.clone() }
}

pub fn validate_address(chain: &str, address: &str) -> bool {
    match chain {
        "ethereum" | "evm" => {
            let body = address.strip_prefix("0x").or_else(|| address.strip_prefix("0X"));
            body.map(|v| v.len() == 40 && v.chars().all(|c| c.is_ascii_hexdigit())).unwrap_or(false)
        }
        "bitcoin" | "btc" => {
            if address.starts_with("bc1") || address.starts_with("tb1") {
                address.len() >= 14 && address.chars().all(|c| c.is_ascii_alphanumeric())
            } else if address.starts_with('1') || address.starts_with('3') || address.starts_with('m') || address.starts_with('n') || address.starts_with('2') {
                address.len() >= 26 && address.len() <= 62 && address.chars().all(|c| c.is_ascii_alphanumeric())
            } else { false }
        }
        _ => false,
    }
}

pub fn normalize_watch_addresses(items: &[WatchedAddress]) -> Vec<WatchedAddress> {
    let mut seen = HashSet::new();
    items.iter().filter_map(|item| {
        let key = format!("{}:{}", item.chain.to_ascii_lowercase(), item.address.to_ascii_lowercase());
        if seen.insert(key) { Some(item.clone()) } else { None }
    }).collect()
}
