#!/usr/bin/env bash
set -euo pipefail
BASE="${TITAN_BASE_URL:-http://127.0.0.1:8080}"
TOKEN="${OPERATOR_API_TOKEN:-dev-token}"

echo '[1/4] health'
curl -fsS "$BASE/health" >/dev/null

echo '[2/4] blockchain status'
curl -fsS "$BASE/blockchain/status" >/dev/null

echo '[3/4] add watch'
curl -fsS -X POST "$BASE/blockchain/watch" -H "Authorization: Bearer $TOKEN" -H 'content-type: application/json' \
  -d '{"address":"0x0000000000000000000000000000000000000001","chain":"ethereum","label":"sentinel-test","expected_balance":0,"tolerance":0}' >/dev/null

echo '[4/4] fee policy'
curl -fsS -X POST "$BASE/blockchain/fees/evaluate" -H "Authorization: Bearer $TOKEN" -H 'content-type: application/json' \
  -d '{"chain":"bitcoin","observed_fee_rate":12,"recommended_fee_rate":8,"max_allowed_fee_rate":20,"elevated":false,"rejected":false}' >/dev/null

echo 'Titan blockchain safety integration: OK'
