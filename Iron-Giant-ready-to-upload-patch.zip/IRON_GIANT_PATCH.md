# Iron-Giant patch

This patch is intentionally conservative. It fixes the malformed Rust module
identifier found in `titan-core/src/lib.rs`, adds a small health-state module,
and adds a repeatable workspace validation script.

## Validate locally

```bash
./scripts/check.sh
```

Or run the individual commands:

```bash
cargo fmt --all
cargo check --workspace --all-targets
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
```

Review the diff before pushing:

```bash
git diff --check
git diff
```

Then commit:

```bash
git add .
git commit -m "Fix Iron-Giant Rust build and add validation"
git push
```
