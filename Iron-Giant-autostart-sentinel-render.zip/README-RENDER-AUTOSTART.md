# Iron-Giant automatic Render startup

The control-plane binary starts the Sentinel automatically when the Render service/container starts. There is no separate startup command.

## Required Render environment

Set these once in the Render service environment: `TITAN_RPC_WS_URL`, `TITAN_USDC_CONTRACTS`, and `TITAN_USDT_CONTRACTS`. The quarantine wallet is preconfigured in `render.yaml`.

Once the container starts, the Sentinel connects to the configured EVM WebSocket endpoint, subscribes to new blocks, observes transactions, decodes configured USDC/USDT `Transfer` logs, marks each matching transfer HIGH risk, and emits the quarantine policy event for downstream authorized custody handling.

The public-chain monitor remains read-only. It does not sign or rewrite third-party transactions. Actual custody movement requires an authorized enforcement/custody boundary.

Render uses the Dockerfile `CMD`, so no manual shell/start command is required.
