use serde::{Deserialize, Serialize};

/// Minimal autonomous-agent state for the initial control-plane build.
/// Agents produce observations; enforcement remains outside this type.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AutonomousAgent {
    pub name: String,
    pub enabled: bool,
}

impl AutonomousAgent {
    pub fn new(name: impl Into<String>) -> Self {
        Self { name: name.into(), enabled: true }
    }
}
