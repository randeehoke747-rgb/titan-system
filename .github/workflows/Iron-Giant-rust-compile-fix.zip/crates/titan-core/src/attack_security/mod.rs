use serde::{Deserialize, Serialize};

/// Lightweight detector state used by the control plane.
/// This is intentionally policy-neutral: it reports observations and does not
/// authorize or execute transactions.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct KeyCompromiseDetector {
    pub suspicious: bool,
}

impl KeyCompromiseDetector {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn observe(&mut self, suspicious: bool) {
        self.suspicious = suspicious;
    }
}
