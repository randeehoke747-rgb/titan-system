use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KeyCompromiseDetector {
    pub enabled: bool,
}

impl Default for KeyCompromiseDetector {
    fn default() -> Self { Self { enabled: true } }
}
