use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AutonomousAgent {
    pub name: String,
    pub enabled: bool,
}

impl AutonomousAgent {
    pub fn new(name: impl Into<String>) -> Self {
        Self { name: name.into(), enabled: true }
    }
}
