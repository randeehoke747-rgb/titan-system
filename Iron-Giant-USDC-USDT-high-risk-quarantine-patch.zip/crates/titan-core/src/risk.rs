use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum RiskLevel {
    High,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum EnforcementAction {
    QuarantineForReview,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskAssessment {
    pub risk: RiskLevel,
    pub action: EnforcementAction,
    pub reason: String,
}

impl RiskAssessment {
    pub fn high_risk_stablecoin() -> Self {
        Self {
            risk: RiskLevel::High,
            action: EnforcementAction::QuarantineForReview,
            reason: "Iron-Giant policy: all stablecoin transfers are high risk by default".into(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QuarantineRequest {
    pub chain_id: u64,
    pub block_number: u64,
    pub transaction_hash: String,
    pub token: String,
    pub token_contract: String,
    pub original_from: String,
    pub original_to: String,
    pub amount: String,
    pub quarantine_wallet: String,
    pub assessment: RiskAssessment,
}
