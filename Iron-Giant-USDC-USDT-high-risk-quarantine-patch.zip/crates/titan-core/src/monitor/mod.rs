use futures_util::{SinkExt, StreamExt};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::{collections::{HashMap, HashSet}, env};
use tokio::sync::broadcast;
use tokio::time::{sleep, Duration};
use tokio_tungstenite::{connect_async, tungstenite::Message};
use tracing::{info, warn};
use crate::risk::{QuarantineRequest, RiskAssessment};

const TRANSFER_TOPIC: &str = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChainTransaction {
    pub chain_id: u64,
    pub block_number: u64,
    pub transaction_hash: String,
    pub from: String,
    pub to: Option<String>,
    pub value: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StablecoinTransfer {
    pub chain_id: u64,
    pub block_number: u64,
    pub transaction_hash: String,
    pub token: String,
    pub token_contract: String,
    pub from: String,
    pub to: String,
    pub amount: String,
    pub risk: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ChainEvent {
    Transaction(ChainTransaction),
    StablecoinTransfer(StablecoinTransfer),
    Quarantine(QuarantineRequest),
}

#[derive(Debug, Clone)]
pub struct MonitorConfig {
    pub rpc_ws_url: String,
    pub chain_id: u64,
    pub stablecoin_contracts: HashMap<String, String>,
    pub quarantine_wallet: String,
}

impl MonitorConfig {
    pub fn from_env() -> Result<Self, String> {
        let rpc_ws_url = env::var("TITAN_RPC_WS_URL")
            .map_err(|_| "TITAN_RPC_WS_URL is required".to_string())?;
        let chain_id = env::var("TITAN_CHAIN_ID")
            .unwrap_or_else(|_| "1".into())
            .parse()
            .map_err(|_| "TITAN_CHAIN_ID must be an integer".to_string())?;
        let quarantine_wallet = env::var("TITAN_QUARANTINE_WALLET")
            .map_err(|_| "TITAN_QUARANTINE_WALLET is required".to_string())?;
        let mut stablecoin_contracts = HashMap::new();
        parse_contracts(&mut stablecoin_contracts, "USDC", "TITAN_USDC_CONTRACTS");
        parse_contracts(&mut stablecoin_contracts, "USDT", "TITAN_USDT_CONTRACTS");
        Ok(Self { rpc_ws_url, chain_id, stablecoin_contracts, quarantine_wallet })
    }
}

fn parse_contracts(out: &mut HashMap<String, String>, token: &str, variable: &str) {
    if let Ok(value) = env::var(variable) {
        for address in value.split(',').map(str::trim).filter(|s| !s.is_empty()) {
            out.insert(address.to_ascii_lowercase(), token.to_string());
        }
    }
}

/// Read-only public-chain monitor. It observes data exposed by an authorized RPC endpoint.
/// It never signs, modifies, censors, or redirects a public transaction.
/// Quarantine events are policy decisions for an authorized custody/enforcement boundary.
pub struct TransactionMonitor {
    tx: broadcast::Sender<ChainEvent>,
}

impl TransactionMonitor {
    pub fn new(capacity: usize) -> Self {
        let (tx, _) = broadcast::channel(capacity);
        Self { tx }
    }

    pub fn subscribe(&self) -> broadcast::Receiver<ChainEvent> { self.tx.subscribe() }

    pub fn publish(&self, event: ChainEvent) { let _ = self.tx.send(event); }

    pub async fn run(self, config: MonitorConfig) -> Result<(), String> {
        let mut backoff = 1u64;
        loop {
            match self.run_connection(&config).await {
                Ok(()) => backoff = 1,
                Err(err) => warn!(error = %err, "Iron-Giant chain monitor disconnected"),
            }
            sleep(Duration::from_secs(backoff)).await;
            backoff = (backoff * 2).min(30);
        }
    }

    async fn run_connection(&self, config: &MonitorConfig) -> Result<(), String> {
        let (ws, _) = connect_async(&config.rpc_ws_url)
            .await.map_err(|e| format!("websocket connect failed: {e}"))?;
        let (mut write, mut read) = ws.split();
        write.send(Message::Text(json!({
            "jsonrpc":"2.0", "id":1, "method":"eth_subscribe", "params":["newHeads"]
        }).to_string().into())).await.map_err(|e| e.to_string())?;

        let mut subscription_id: Option<String> = None;
        info!(chain_id = config.chain_id, stablecoins = ?config.stablecoin_contracts, "Iron-Giant Sentinel connected");

        while let Some(message) = read.next().await {
            let Message::Text(text) = message.map_err(|e| e.to_string())? else { continue };
            let value: Value = serde_json::from_str(&text).map_err(|e| format!("invalid RPC JSON: {e}"))?;
            if value.get("id") == Some(&json!(1)) {
                subscription_id = value.get("result").and_then(Value::as_str).map(str::to_owned);
                continue;
            }
            if value.get("method") == Some(&json!("eth_subscription"))
                && value.pointer("/params/subscription").and_then(Value::as_str) == subscription_id.as_deref()
            {
                if let Some(hash) = value.pointer("/params/result/hash").and_then(Value::as_str) {
                    let tx = self.tx.clone();
                    let cfg = config.clone();
                    let url = config.rpc_ws_url.clone();
                    let block_hash = hash.to_owned();
                    tokio::spawn(async move {
                        if let Err(e) = fetch_and_publish(url, cfg, block_hash, tx).await {
                            warn!(error = %e, "block processing failed");
                        }
                    });
                }
            }
        }
        Ok(())
    }

    pub fn is_transfer_topic(topic: &str) -> bool { topic.eq_ignore_ascii_case(TRANSFER_TOPIC) }
}

async fn fetch_and_publish(
    url: String,
    config: MonitorConfig,
    block_hash: String,
    tx: broadcast::Sender<ChainEvent>,
) -> Result<(), String> {
    let (ws, _) = connect_async(&url).await.map_err(|e| e.to_string())?;
    let (mut write, mut read) = ws.split();
    write.send(Message::Text(json!({
        "jsonrpc":"2.0", "id":2, "method":"eth_getBlockByHash", "params":[block_hash, true]
    }).to_string().into())).await.map_err(|e| e.to_string())?;

    let mut block_number = 0u64;
    let mut transaction_hashes = Vec::new();
    while let Some(message) = read.next().await {
        let Message::Text(text) = message.map_err(|e| e.to_string())? else { continue };
        let value: Value = serde_json::from_str(&text).map_err(|e| e.to_string())?;
        if value.get("id") != Some(&json!(2)) { continue; }
        let Some(block) = value.get("result") else { break; };
        block_number = hex_u64(block.get("number").and_then(Value::as_str).unwrap_or("0x0"))?;
        let transactions = block.get("transactions").and_then(Value::as_array).cloned().unwrap_or_default();
        for raw in transactions {
            let hash = raw.get("hash").and_then(Value::as_str).unwrap_or_default().to_owned();
            transaction_hashes.push(hash.clone());
            let event = ChainEvent::Transaction(ChainTransaction {
                chain_id: config.chain_id,
                block_number,
                transaction_hash: hash,
                from: raw.get("from").and_then(Value::as_str).unwrap_or_default().to_owned(),
                to: raw.get("to").and_then(Value::as_str).map(str::to_owned),
                value: raw.get("value").and_then(Value::as_str).unwrap_or("0x0").to_owned(),
            });
            let _ = tx.send(event);
        }
        break;
    }

    // One block-scoped eth_getLogs request catches ERC-20 transfers without requiring
    // a receipt RPC call for every transaction. Every matching USDC/USDT transfer is HIGH risk.
    if !config.stablecoin_contracts.is_empty() {
        let (ws2, _) = connect_async(&url).await.map_err(|e| e.to_string())?;
        let (mut write2, mut read2) = ws2.split();
        write2.send(Message::Text(json!({
            "jsonrpc":"2.0", "id":3, "method":"eth_getLogs", "params":[{
                "fromBlock": format!("0x{block_number:x}"),
                "toBlock": format!("0x{block_number:x}"),
                "address": config.stablecoin_contracts.keys().collect::<Vec<_>>(),
                "topics": [TRANSFER_TOPIC]
            }]
        }).to_string().into())).await.map_err(|e| e.to_string())?;

        while let Some(message) = read2.next().await {
            let Message::Text(text) = message.map_err(|e| e.to_string())? else { continue };
            let value: Value = serde_json::from_str(&text).map_err(|e| e.to_string())?;
            if value.get("id") != Some(&json!(3)) { continue; }
            for log in value.get("result").and_then(Value::as_array).cloned().unwrap_or_default() {
                if let Some(event) = decode_transfer_log(&log, &config)? {
                    let _ = tx.send(ChainEvent::StablecoinTransfer(event.clone()));
                    let _ = tx.send(ChainEvent::Quarantine(QuarantineRequest {
                        chain_id: event.chain_id,
                        block_number: event.block_number,
                        transaction_hash: event.transaction_hash,
                        token: event.token,
                        token_contract: event.token_contract,
                        original_from: event.from,
                        original_to: event.to,
                        amount: event.amount,
                        quarantine_wallet: config.quarantine_wallet.clone(),
                        assessment: RiskAssessment::high_risk_stablecoin(),
                    }));
                }
            }
            break;
        }
    }
    let _ = transaction_hashes;
    Ok(())
}

fn decode_transfer_log(log: &Value, config: &MonitorConfig) -> Result<Option<StablecoinTransfer>, String> {
    let contract = log.get("address").and_then(Value::as_str).unwrap_or_default().to_ascii_lowercase();
    let Some(token) = config.stablecoin_contracts.get(&contract) else { return Ok(None); };
    let topics = log.get("topics").and_then(Value::as_array).cloned().unwrap_or_default();
    if topics.len() < 3 || !TransactionMonitor::is_transfer_topic(topics[0].as_str().unwrap_or_default()) {
        return Ok(None);
    }
    let from = topic_address(&topics[1])?;
    let to = topic_address(&topics[2])?;
    let amount = log.get("data").and_then(Value::as_str).unwrap_or("0x0").to_owned();
    let block_number = hex_u64(log.get("blockNumber").and_then(Value::as_str).unwrap_or("0x0"))?;
    let hash = log.get("transactionHash").and_then(Value::as_str).unwrap_or_default().to_owned();
    Ok(Some(StablecoinTransfer {
        chain_id: config.chain_id,
        block_number,
        transaction_hash: hash,
        token: token.clone(),
        token_contract: contract,
        from,
        to,
        amount,
        risk: "HIGH".into(),
    }))
}

fn topic_address(topic: &Value) -> Result<String, String> {
    let value = topic.as_str().unwrap_or_default();
    let hex = value.trim_start_matches("0x");
    if hex.len() != 64 { return Err("ERC-20 address topic must contain 32 bytes".into()); }
    Ok(format!("0x{}", &hex[24..]))
}

fn hex_u64(s: &str) -> Result<u64, String> {
    u64::from_str_radix(s.trim_start_matches("0x"), 16).map_err(|e| format!("invalid hex number: {e}"))
}
