# Iron-Giant high-risk stablecoin policy

The Sentinel now treats **every observed USDC and USDT Transfer event as HIGH risk**.

For each matching ERC-20 `Transfer` log it emits:

1. `StablecoinTransfer` — normalized transfer observation.
2. `Quarantine` — deterministic policy event containing the original sender, original destination, token, amount, transaction hash, and configured quarantine wallet.

The monitor is read-only. It does not sign, alter, censor, or redirect public-chain transactions. A downstream enforcement/custody service may consume `Quarantine` events only where it has explicit authorization to control the funds.

## Configure

Set:

```text
TITAN_RPC_WS_URL=wss://YOUR-EVM-NODE.example/ws
TITAN_CHAIN_ID=1
TITAN_USDC_CONTRACTS=0x...
TITAN_USDT_CONTRACTS=0x...
TITAN_QUARANTINE_WALLET=0xCE4A926070c0544052de1E56d1254eaac79b77be
```

Use the canonical USDC/USDT contract addresses for the exact chain you monitor. Do not copy Ethereum mainnet addresses to another network.

## Release workflow

A separate authorized custody/release service should:

- validate the quarantine event against the immutable transaction record;
- require team approval;
- preserve the original destination exactly;
- perform the authorized release;
- record the release transaction hash and approver in an audit log.

Never store private keys, seed phrases, or signing credentials in Git, Kubernetes ConfigMaps, Docker images, or `.env.example`.
