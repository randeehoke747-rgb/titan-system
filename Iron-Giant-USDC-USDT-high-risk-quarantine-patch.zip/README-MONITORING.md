# Iron-Giant public-chain monitoring

Iron-Giant can observe public EVM blockchain data through an authorized WebSocket RPC endpoint.

The monitor is intentionally **read-only**: it can ingest blocks/transactions and classify configured
stablecoin transfer events, but it cannot sign, alter, censor, or redirect third-party transactions.

## Configuration

Copy `.env.example` to `.env` and set:

- `TITAN_RPC_WS_URL`: an authorized EVM WebSocket RPC endpoint.
- `TITAN_CHAIN_ID`: the network to observe.
- `TITAN_USDC_CONTRACTS`: comma-separated USDC contract addresses for that network.

For multiple chains, run one monitor instance per chain so chain IDs and token contracts cannot be mixed.

## Performance design

The monitor uses a bounded Tokio broadcast channel (`65,536` events by default) for low-overhead fan-out.
Consumers should process events asynchronously and keep expensive AI analysis off the ingest path.

A production chain adapter should implement WebSocket reconnect/backoff, `newHeads` subscription, block fetch,
transaction decoding, ERC-20 `Transfer` log decoding, and metrics for lag/dropped events.
