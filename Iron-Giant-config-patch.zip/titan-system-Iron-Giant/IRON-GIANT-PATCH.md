# Iron-Giant configuration patch

This patch adds validated configuration for the operator-designated USDC quarantine wallet and fixes the invalid `attack security` Rust module syntax.

The wallet address is configuration only. This patch does not implement automatic blockchain interception, transfer signing, or fund redirection.

## Apply

From the repository root, merge these files over the existing tree, then run:

```bash
cargo fmt --all
cargo check --workspace --all-targets
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
```

For local non-Kubernetes execution, set `TITAN_USDC_QUARANTINE_WALLET` before starting the service.

For Kubernetes, `k8s/quarantine-config.yaml` supplies the public destination and the deployment reads it through environment variables.

Never add private keys or seed phrases to Git, ConfigMaps, Dockerfiles, or `.env.example`.
