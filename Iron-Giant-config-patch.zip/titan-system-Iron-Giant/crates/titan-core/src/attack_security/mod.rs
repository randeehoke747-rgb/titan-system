#[derive(Debug, Clone, Copy, Default)]
pub struct KeyCompromiseDetector;

impl KeyCompromiseDetector {
    pub fn new() -> Self {
        Self
    }
}
