#[derive(Debug, Clone, Default)]
pub struct AutonomousAgent;

impl AutonomousAgent {
    pub fn new() -> Self {
        Self
    }
}
