use std::{env, fmt};

const USDC_QUARANTINE_ENV: &str = "TITAN_USDC_QUARANTINE_WALLET";

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WalletConfig {
    pub usdc_quarantine_wallet: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TitanConfig {
    pub wallets: WalletConfig,
    pub quarantine_enabled: bool,
    pub require_authorization: bool,
    pub require_verification_before_release: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum WalletConfigError {
    Missing,
    InvalidFormat,
}

impl fmt::Display for WalletConfigError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Missing => write!(f, "{USDC_QUARANTINE_ENV} is not set"),
            Self::InvalidFormat => write!(f, "USDC quarantine wallet must be 0x followed by 40 hexadecimal characters"),
        }
    }
}

impl std::error::Error for WalletConfigError {}

impl TitanConfig {
    pub fn from_env() -> Result<Self, WalletConfigError> {
        let wallet = env::var(USDC_QUARANTINE_ENV).map_err(|_| WalletConfigError::Missing)?;
        if !is_evm_address(&wallet) {
            return Err(WalletConfigError::InvalidFormat);
        }

        Ok(Self {
            wallets: WalletConfig { usdc_quarantine_wallet: wallet },
            quarantine_enabled: env_bool("TITAN_QUARANTINE_ENABLED", true),
            require_authorization: env_bool("TITAN_QUARANTINE_REQUIRE_AUTHORIZATION", true),
            require_verification_before_release: env_bool("TITAN_QUARANTINE_REQUIRE_VERIFICATION", true),
        })
    }
}

fn env_bool(name: &str, default: bool) -> bool {
    env::var(name)
        .ok()
        .map(|v| matches!(v.trim().to_ascii_lowercase().as_str(), "1" | "true" | "yes" | "on"))
        .unwrap_or(default)
}

fn is_evm_address(value: &str) -> bool {
    value.len() == 42
        && value.starts_with("0x")
        && value.as_bytes()[2..].iter().all(|b| b.is_ascii_hexdigit())
}

#[cfg(test)]
mod tests {
    use super::is_evm_address;

    #[test]
    fn accepts_evm_address_shape() {
        assert!(is_evm_address("0xCE4A926070c0544052de1E56d1254eaac79b77be"));
    }

    #[test]
    fn rejects_wrong_length() {
        assert!(!is_evm_address("0x1234"));
    }
}
