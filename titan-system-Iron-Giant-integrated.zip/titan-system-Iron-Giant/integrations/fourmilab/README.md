# Fourmilab Blockchain Tools integration

Titan uses Fourmilab Blockchain Tools as a **read-only blockchain-analysis reference/integration boundary**. The upstream project provides address monitoring, confirmation monitoring, fee analysis, and cold-storage monitoring. It does not generate transactions or require an unlocked wallet.

Upstream: https://github.com/Fourmilab/blockchain_tools
License: Creative Commons Attribution-ShareAlike (see the upstream LICENSE.md).

Titan's Rust transaction gateway is the enforcement boundary: it evaluates transactions before an application is allowed to broadcast them. It does not import or execute Fourmilab code with wallet-signing privileges.

Recommended deployment pattern:

1. Run the desired Fourmilab read-only watcher in a separate process/container.
2. Emit normalized observations to Titan's monitoring/event layer.
3. Let Titan's transaction gateway evaluate a proposed transaction before broadcast.
4. Quarantine suspicious activity for authorized review; do not automatically move funds solely because a watcher raised an alert.

This separation keeps the monitoring tools read-only while making Titan's policy engine the explicit control point.
