#!/usr/bin/env bash
set -euo pipefail

: "${TITAN_URL:=http://127.0.0.1:8080}"
: "${OPERATOR_API_TOKEN:=change-me}"

curl -fsS "$TITAN_URL/health" >/dev/null
curl -fsS "$TITAN_URL/security/status"
printf '\n'

curl -fsS -X POST "$TITAN_URL/security/transaction/evaluate" \
  -H "Authorization: Bearer $OPERATOR_API_TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"chain_id":1,"token":"USDC","token_contract":"0xexample","from":"0x1111111111111111111111111111111111111111","to":"0x2222222222222222222222222222222222222222","amount":"100","transaction_hash":"0xsmoke"}'
printf '\n'
