#!/usr/bin/env bash
set -euo pipefail

cargo fmt --all -- --check
cargo check --workspace --all-targets
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings

if command -v kubectl >/dev/null 2>&1; then
  kubectl kustomize k8s/ >/dev/null
  echo "Kubernetes manifests render successfully."
fi

echo "Titan/Iron-Giant checks passed."
