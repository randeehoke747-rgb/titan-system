# Third-party components

## Fourmilab Blockchain Tools
- Repository: https://github.com/Fourmilab/blockchain_tools
- License: Creative Commons Attribution-ShareAlike
- Used by Titan as a read-only monitoring/analysis integration boundary.
- No upstream private keys are stored in this repository.
