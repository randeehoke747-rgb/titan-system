use serde::{Deserialize, Serialize};

use crate::risk::{EnforcementAction, RiskAssessment};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct TransactionPreflightRequest {
    pub chain_id: u64,
    pub token: Option<String>,
    pub token_contract: Option<String>,
    pub from: String,
    pub to: String,
    pub amount: Option<String>,
    pub transaction_hash: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct TransactionPreflightResponse {
    pub allowed_to_broadcast: bool,
    pub intercepted: bool,
    pub quarantine_wallet: Option<String>,
    pub assessment: RiskAssessment,
}

#[derive(Debug, Clone)]
pub struct TransactionGateway {
    safe_wallet: Option<String>,
}

impl TransactionGateway {
    pub fn new(safe_wallet: Option<String>) -> Self {
        Self { safe_wallet }
    }

    pub fn safe_wallet(&self) -> Option<&str> {
        self.safe_wallet.as_deref()
    }

    /// Pre-broadcast security decision only. This function never signs, broadcasts,
    /// transfers, or changes funds. A quarantine result is an authorization boundary
    /// for an external custody workflow to review.
    pub fn evaluate(&self, request: &TransactionPreflightRequest) -> TransactionPreflightResponse {
        if request.from.trim().is_empty() || request.to.trim().is_empty() {
            return TransactionPreflightResponse {
                allowed_to_broadcast: false,
                intercepted: true,
                quarantine_wallet: self.safe_wallet.clone(),
                assessment: RiskAssessment::reject("from and to addresses are required"),
            };
        }

        let stablecoin = request
            .token
            .as_deref()
            .map(|token| matches!(token.to_ascii_uppercase().as_str(), "USDC" | "USDT"))
            .unwrap_or(false);

        let assessment = if stablecoin {
            RiskAssessment::high_risk_stablecoin()
        } else {
            RiskAssessment::allow()
        };

        let intercepted = assessment.action != EnforcementAction::Allow;
        TransactionPreflightResponse {
            allowed_to_broadcast: assessment.action == EnforcementAction::Allow,
            intercepted,
            quarantine_wallet: if intercepted { self.safe_wallet.clone() } else { None },
            assessment,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn request(token: Option<&str>) -> TransactionPreflightRequest {
        TransactionPreflightRequest {
            chain_id: 1,
            token: token.map(str::to_owned),
            token_contract: None,
            from: "0x1111111111111111111111111111111111111111".into(),
            to: "0x2222222222222222222222222222222222222222".into(),
            amount: Some("100".into()),
            transaction_hash: None,
        }
    }

    #[test]
    fn stablecoins_are_intercepted_before_broadcast() {
        let gateway = TransactionGateway::new(Some("0xsafe".into()));
        let result = gateway.evaluate(&request(Some("USDC")));
        assert!(result.intercepted);
        assert!(!result.allowed_to_broadcast);
        assert_eq!(result.quarantine_wallet.as_deref(), Some("0xsafe"));
    }

    #[test]
    fn non_stablecoin_passes_basic_preflight() {
        let gateway = TransactionGateway::new(None);
        let result = gateway.evaluate(&request(Some("WAGMI")));
        assert!(!result.intercepted);
        assert!(result.allowed_to_broadcast);
    }
}
