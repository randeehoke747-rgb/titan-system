use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum RiskLevel {
    Low,
    Medium,
    High,
    Critical,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum EnforcementAction {
    Allow,
    QuarantineForReview,
    Reject,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct RiskAssessment {
    pub risk: RiskLevel,
    pub action: EnforcementAction,
    pub reason: String,
}

impl RiskAssessment {
    pub fn high_risk_stablecoin() -> Self {
        Self {
            risk: RiskLevel::High,
            action: EnforcementAction::QuarantineForReview,
            reason: "Iron-Giant policy: stablecoin transfers require transaction-gateway review by default.".into(),
        }
    }

    pub fn allow() -> Self {
        Self {
            risk: RiskLevel::Low,
            action: EnforcementAction::Allow,
            reason: "Transaction passed the configured preflight policy.".into(),
        }
    }

    pub fn reject(reason: impl Into<String>) -> Self {
        Self {
            risk: RiskLevel::Critical,
            action: EnforcementAction::Reject,
            reason: reason.into(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct QuarantineRequest {
    pub chain_id: u64,
    pub block_number: u64,
    pub transaction_hash: String,
    pub token: String,
    pub token_contract: String,
    pub original_from: String,
    pub original_to: String,
    pub amount: String,
    pub quarantine_wallet: String,
    pub assessment: RiskAssessment,
}
