# Build status

The repository was integrated from the uploaded `titan-system-Iron-Giant (2).zip` and the uploaded Iron-Giant quarantine/sentinel patches.

The execution environment used to assemble this package does not contain the Rust toolchain (`cargo`/`rustc`), so a local `cargo test` could not be executed here. The GitHub Actions CI is configured to run formatting, check, tests, clippy, and Docker build on a Rust-enabled runner.

Before deployment, run:

```bash
cargo fmt --all -- --check
cargo check --workspace --all-targets
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
docker build -t titan-system:local .
```

No transaction is broadcast by the new security gateway or sentinel.
