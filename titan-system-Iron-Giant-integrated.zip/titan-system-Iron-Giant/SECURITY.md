# Titan security boundary

Titan now has three explicit layers:

1. **Read-only chain sentinel** — observes authorized EVM RPC data and emits transaction/stablecoin events.
2. **Transaction gateway** — performs a pre-broadcast policy decision. USDC/USDT are intercepted and returned as `quarantine_for_review` by default.
3. **Operator/custody boundary** — any actual movement of funds remains outside the Titan process and requires an explicitly authorized custody workflow.

The gateway does not hold, export, or automatically move private keys or funds. The `SAFE_WALLET_ADDRESS` and `TITAN_QUARANTINE_WALLET` values are destinations for an external authorized workflow; they are not used by Titan to sign transactions.

This is intentional: the system can stop a risky transaction before broadcast without giving an autonomous agent unilateral custody of assets.
